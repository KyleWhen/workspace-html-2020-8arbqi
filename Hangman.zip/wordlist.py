#import the random module
import random
#list of words of the year from Merriam Webster Dictionary website as well as some general computer science terms
words = [
    "Democracy"
    "Blog"
    "Integrity"
    "Truthiness"
    "Woot"
    "Bailout"
    "Admonish"
    "Austerity"
    "Prgagmatic"
    "Capitalism"
    "Culture"
    "Ism"
    "Surreal"
    "Feminism"
    "Justice"
    "
    "Computer",
    "Science",
    "Python",
    "Module",
    "Import",
    "Print",
    "Def",
    "For",
    "Blackboard",
    "Java"
    ]
def get_random_word():
    word = random.choice(words)
    return word
